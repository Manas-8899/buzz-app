import React, { Component } from 'react';
import { Text, View, StyleSheet, Button } from 'react-native';

export default class Facebook extends Component {
  render() {
    return (
      <View style={{flex:1, justifyContent:"center", alignItems: "center"}}>
        <Text style = {{fontSize: 30 }}>This is Facebook</Text>
      </View>
    )
  }
}